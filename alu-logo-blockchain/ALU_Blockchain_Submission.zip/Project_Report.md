# Project Report

## Abstract
This project implements a blockchain-based system to register and fractionalize the African Leadership University (ALU) logo. By leveraging an ERC-721 smart contract to establish immutable proof of authenticity and an ERC-20 contract to split ownership into distributable tokens, this solution ensures transparent, decentralized verification and stakeholder ownership tracking.

## Introduction
ALU needs to protect its logo on a blockchain because traditional databases and copyright registries rely on centralized authorities, which are vulnerable to alteration, deletion, or loss. A blockchain provides an immutable, decentralized ledger where the exact state and timestamp of registration are permanently recorded. This ensures undeniable cryptographic proof of existence and authenticity that any party can verify independently without relying on a central entity.

## Blockchain Setup
A local blockchain is a simulated network running locally on a developer's computer. Developers use it instead of the real Ethereum network to test smart contracts for free, without spending real ETH, and with instant transaction mining. 

Hardhat was set up to spin up this local node. It compiles the Solidity contracts, creates a local blockchain environment, and provides dummy wallet addresses pre-funded with fake ETH. 
A wallet address is a unique identifier (like a bank account number) on the blockchain that represents a user's account, holding their funds and interacting with smart contracts.

## Smart Contract Explanation
A smart contract is a self-executing program deployed on a blockchain. Unlike standard programs that run on centralized servers (where code can be secretly changed by administrators), smart contracts run on a decentralized network where their code and data are public, immutable, and strictly enforce the agreed-upon logic.

An NFT (Non-Fungible Token) is a unique digital asset. The ERC-721 standard is the industry standard for NFTs because it allows each token to have distinct properties and a unique ID, making it ideal for registering a one-of-a-kind asset like the ALU Logo.

A SHA-256 hash is a cryptographic function that converts any file into a unique 64-character string of letters and numbers. Changing even a single pixel in an image alters the file's binary data completely, resulting in a fundamentally different hash (the "avalanche effect"). 

Data stored on a blockchain cannot be changed because each block of data is cryptographically linked to the previous one in a chain. Altering data requires rewriting the entire chain and gaining majority control over a massive decentralized network, making it practically impossible.

### Functions Created:
- **`registerAsset()`**: Evaluates the inputted name, file type, and file hash. It checks if the hash has already been registered to reject duplicates, then issues an NFT (token) to the caller, permanently linking the metadata to the token ID.
- **`verifyLogoIntegrity()`**: Accepts a token ID and a hash, checking if the submitted hash perfectly matched the stored hash. It returns true if it matches and false if it doesn't.
- **`getAsset()`**: Retrieves and returns the full registration details containing the asset's name, file type, hash, the registrar's wallet, and the exact timestamp.
- **`distributeShares()`**: Allows the owner of the ALUT tokens to send shares to a specified user address.
- **`ownershipPercentage()`**: Calculates and returns what percentage of the total tokens a specific wallet holds.

**ALU Logo Hash:** Replace this with the hash generated when you run `npx hardhat run scripts/deploy.js`. 

## Tokenisation
Tokenisation is the process of splitting ownership of a single asset into multiple digital tokens, allowing multiple people to hold fractional stakes.

For the ALU logo, tokens could be distributed to the university founder (retaining majority control), the primary designer (as a royalty/credit), and perhaps student council members or alumni (as symbolic ownership). 

ERC-721 is used for the logo registration because it represents a unique, indivisible asset (the registration itself). ERC-20 is used for ownership shares because the shares are fungible—meaning any one ALUT token is exactly identical in value and function to any other ALUT token.

If a faculty member holds 100,000 ALUT tokens out of 1,000,000 total, it means they mathematically own a 10% share of the asset. In practice, they hold verifiable proof of their 10% stake which could entitle them to proportional voting rights or royalties.

## Test Results
*(Please take a screenshot of your terminal showing passing tests and place it here)*

## Conclusion
Through this project, I learned how to combine both the non-fungible properties of ERC-721 and the fungible nature of ERC-20 to register and tokenize a digital asset. If I had more time, I would build a front-end React interface for users to easily upload images to be hashed and interact with the distribution of shares.

## GitHub Link
*(Insert your GitHub repository link here)*

## Video Link
*(Insert your Video link here)*
